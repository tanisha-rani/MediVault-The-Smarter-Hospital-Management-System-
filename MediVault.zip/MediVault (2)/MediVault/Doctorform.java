import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class Doctorform extends JFrame {

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/MediVault";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "tanisha";

    private JTextField nameField, specializationField, contactField, idField;
    private DefaultTableModel tableModel;
    private java.util.List<String[]> doctorList = new ArrayList<>();

    public Doctorform() {
        setTitle("Add Doctor - MediVault");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Main panel
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));

        JLabel idLabel = new JLabel("Doctor ID:");
        idField = new JTextField();

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();

        JLabel specializationLabel = new JLabel("Specialization:");
        specializationField = new JTextField();

        JLabel contactLabel = new JLabel("Contact:");
        contactField = new JTextField();

        formPanel.add(idLabel);
        formPanel.add(idField);
        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(specializationLabel);
        formPanel.add(specializationField);
        formPanel.add(contactLabel);
        formPanel.add(contactField);

        // Save button
        JButton saveButton = new JButton("Add Doctor");
        saveButton.setBackground(new Color(39, 174, 96));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));

        saveButton.addActionListener(e -> addDoctor());

        formPanel.add(new JLabel()); // Empty cell
        formPanel.add(saveButton);

        // Table panel
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Specialization", "Contact"}, 0);
        JTable doctorTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(doctorTable);

        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);
        setVisible(true);
    }

    private void addDoctor() {
        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        String specialization = specializationField.getText().trim();
        String contact = contactField.getText().trim();

        // Basic validation
        if (id.isEmpty() || name.isEmpty() || specialization.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Check for duplicate ID in memory list
        for (String[] doc : doctorList) {
            if (doc[0].equals(id)) {
                JOptionPane.showMessageDialog(this, "Doctor ID already exists!", "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Add to list and table
        String[] doctorData = {id, name, specialization, contact};
        doctorList.add(doctorData);
        tableModel.addRow(doctorData);

        // Save to database
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO doctor_details (doctor_id, name, specialization, contact) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setString(3, specialization);
            stmt.setString(4, contact);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Clear fields
        idField.setText("");
        nameField.setText("");
        specializationField.setText("");
        contactField.setText("");

        JOptionPane.showMessageDialog(this, "Doctor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Doctorform::new);
    }
}
