import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LabReport extends JFrame {
    private JTable reportTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private final int userId;
    private final boolean isDoctor;

    private final String DB_URL = "jdbc:mysql://localhost:3306/MediVault";
    private final String DB_USER = "root";
    private final String DB_PASS = "tanisha";

    public LabReport(int userId, boolean isDoctor) {
        this.userId = userId;
        this.isDoctor = isDoctor;

        setTitle("🧪 Lab Reports - MediVault");
        setSize(1000, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.decode("#F4F6F7"));

        JLabel headerLabel = new JLabel("🧪 Lab Reports");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        headerLabel.setForeground(new Color(52, 152, 219));

        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setOpaque(false);

        searchField = new JTextField();
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setToolTipText("Search by Name or Test...");
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterTable(searchField.getText().trim());
            }
        });

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);

        // Add Report button for all users
        JButton addReportButton = new JButton("➕ Add Report");
        styleButton(addReportButton, new Color(52, 152, 219));
        addReportButton.addActionListener(e -> showAddReportDialog());
        rightPanel.add(addReportButton);

        if (isDoctor) {
            JButton fetchAllButton = new JButton("📂 View All Reports");
            styleButton(fetchAllButton, new Color(241, 196, 15));
            fetchAllButton.addActionListener(e -> fetchData());
            rightPanel.add(fetchAllButton);
        }

        topPanel.add(headerLabel, BorderLayout.WEST);
        topPanel.add(searchField, BorderLayout.CENTER);
        topPanel.add(rightPanel, BorderLayout.EAST);

        tableModel = new DefaultTableModel(
                new Object[]{"Patient ID", "Name", "Test", "Doctor", "Result", "Date"}, 0);
        reportTable = new JTable(tableModel);
        reportTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        reportTable.setRowHeight(25);
        reportTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        reportTable.setAutoCreateRowSorter(true);

        JScrollPane scrollPane = new JScrollPane(reportTable);
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);

        if (isDoctor) {
            fetchData(); // Doctor sees all by default
        } else {
            showReportsByPatientId(); // Patient enters ID to view their own
        }

        setVisible(true);
    }

    private void styleButton(JButton button, Color bg) {
        button.setFocusPainted(false);
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void fetchData() {
        tableModel.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT patient_id, name, test, doctor_name, result, date FROM lab_report ORDER BY id DESC";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("patient_id"),
                        rs.getString("name"),
                        rs.getString("test"),
                        rs.getString("doctor_name"),
                        rs.getString("result"),
                        rs.getString("date")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void filterTable(String query) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        reportTable.setRowSorter(sorter);
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
    }

    private void showAddReportDialog() {
        JTextField patientIdField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField testField = new JTextField();
        JTextField doctorField = new JTextField();
        JTextField resultField = new JTextField();
        JTextField dateField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Patient ID:"));
        panel.add(patientIdField);
        panel.add(new JLabel("Patient Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Test Name:"));
        panel.add(testField);
        panel.add(new JLabel("Doctor Name:"));
        panel.add(doctorField);
        panel.add(new JLabel("Result:"));
        panel.add(resultField);
        panel.add(new JLabel("Date (YYYY-MM-DD):"));
        panel.add(dateField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Lab Report",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "INSERT INTO lab_report (patient_id, name, test, doctor_name, result, date) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, Integer.parseInt(patientIdField.getText()));
                stmt.setString(2, nameField.getText());
                stmt.setString(3, testField.getText());
                stmt.setString(4, doctorField.getText());
                stmt.setString(5, resultField.getText());
                stmt.setString(6, dateField.getText());
                stmt.executeUpdate();

                // ✅ Updated behavior
                if (isDoctor) {
                    fetchData();
                } else {
                    showReportsByPatientId(); // fetch only patient's data
                }

                JOptionPane.showMessageDialog(this, "Report added successfully.");
            } catch (SQLException | NumberFormatException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to add report.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showReportsByPatientId() {
        String inputId = JOptionPane.showInputDialog(this, "Enter your Patient ID:");
        if (inputId == null || inputId.trim().isEmpty()) return;

        try {
            int patientId = Integer.parseInt(inputId.trim());
            tableModel.setRowCount(0);
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT patient_id, name, test, doctor_name, result, date FROM lab_report WHERE patient_id = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, patientId);
                ResultSet rs = stmt.executeQuery();

                boolean hasData = false;
                while (rs.next()) {
                    hasData = true;
                    tableModel.addRow(new Object[]{
                            rs.getInt("patient_id"),
                            rs.getString("name"),
                            rs.getString("test"),
                            rs.getString("doctor_name"),
                            rs.getString("result"),
                            rs.getString("date")
                    });
                }

                if (!hasData) {
                    JOptionPane.showMessageDialog(this, "No reports found for Patient ID: " + patientId);
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Patient ID entered.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error occurred while fetching reports.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Example usage:
        // true = doctor mode, false = patient mode
        SwingUtilities.invokeLater(() -> new LabReport(0, false));  // change to true for doctor
    }
}
