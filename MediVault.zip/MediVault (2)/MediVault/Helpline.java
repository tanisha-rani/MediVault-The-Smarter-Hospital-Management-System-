import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Helpline extends JPanel {

    private static final Color BUTTON_COLOR = new Color(255, 165, 0);
    private static final Color SOS_COLOR = Color.RED;

    public Helpline() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(300, 180));
        setBackground(new Color(255, 235, 205));
        
        TitledBorder titledBorder = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(255, 140, 0), 2),
                "🆘 Helpline & Emergency",
                TitledBorder.CENTER, TitledBorder.TOP, 
                new Font("Segoe UI", Font.BOLD, 16), Color.RED);

        setBorder(titledBorder);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(3, 1, 10, 10));
        contentPanel.setOpaque(false);

        JPanel callHospitalPanel = createButtonWithText("MediVault/call.png", BUTTON_COLOR, "Call Hospital", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                callHospital();
            }
        });

        JPanel ambulancePanel = createButtonWithText("C:\\Users\\HP\\OneDrive\\Desktop\\JAVA\\MediVaultLatest\\MediVault\\Ambulance.png", BUTTON_COLOR, "Call Ambulance", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                callAmbulance();
            }
        });

        JPanel sosPanel = createButtonWithText("C:\\Users\\HP\\OneDrive\\Desktop\\JAVA\\MediVaultLatest\\MediVault\\SOS.png", SOS_COLOR, "SOS", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                triggerSOS();
            }
        });

        contentPanel.add(callHospitalPanel);
        contentPanel.add(ambulancePanel);
        contentPanel.add(sosPanel);

        add(contentPanel, BorderLayout.CENTER);
    }

    private JPanel createButtonWithText(String iconPath, Color backgroundColor, String text, ActionListener listener) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setOpaque(false);

        JButton button = new JButton(new ImageIcon(iconPath));
        button.setBackground(backgroundColor);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(listener);
        button.setPreferredSize(new Dimension(200, 40));

        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(Color.BLACK);

        panel.add(button, BorderLayout.CENTER);
        panel.add(label, BorderLayout.SOUTH);

        return panel;
    }

    private void callHospital() {
        String message = "Contact Number: +91 9529939474\nAddress: MediVault Hospital\n" + //
                        "Ansari Nagar,\n" + //
                        "New Delhi - 110029,\n" + //
                        "India\n\n" +
                         "Hours: 24/7 Emergency Care\nFor immediate assistance, call our emergency number!";
        JOptionPane.showMessageDialog(this, message, "Call Hospital", JOptionPane.INFORMATION_MESSAGE);
    }

    private void callAmbulance() {
        String message = "Contact Number: +91 6747343830\nFor immediate ambulance services, please call our emergency number!";
        JOptionPane.showMessageDialog(this, message, "Call Ambulance", JOptionPane.INFORMATION_MESSAGE);
    }

    private void triggerSOS() {
        String message = "Emergency SOS triggered! Your location has been shared with emergency services.\n" +
                         "An ambulance is on the way!";
        JOptionPane.showMessageDialog(this, message, "SOS Alert", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Hospital App - Helpline");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);

        Helpline helplineCard = new Helpline();
        frame.add(helplineCard);

        frame.setVisible(true);
    }
}