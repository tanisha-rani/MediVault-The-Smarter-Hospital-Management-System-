import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminForm extends JFrame {
    private JLabel titleLabel;
    private String titleText = "𝓜𝓮𝓭𝓲𝓥𝓪𝓾𝓵𝓽 - Admin Panel";
    private Image backgroundImage;

    public AdminForm() {
        setTitle("🧠 MediVault");
        setSize(1000, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try {
            backgroundImage = new ImageIcon("C:\\Users\\HP\\OneDrive\\Desktop\\JAVA\\MediVaultLatest\\MediVault\\Background Image.jpg").getImage(); // Make sure this path is correct
        } catch (Exception e) {
            System.err.println("Background image not found.");
            backgroundImage = null;
        }

        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        titleLabel = new JLabel("<html><div style='"
                + "font-family: Poppins, Arial, sans-serif; "
                + "font-size: 56px; "
                + "font-weight: 900; "
                + "letter-spacing: 6px; "
                + "color: #00FFC6; "
                + "text-shadow: 3px 3px 15px rgba(0,0,0,0.5); "
                + "font-style: italic;'>"
                + titleText
                + "</div></html>", SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(titleLabel);
        headerPanel.add(titlePanel, BorderLayout.CENTER);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Admin options
        JPanel gridPanel = new JPanel(new GridLayout(3, 3, 25, 25));
        gridPanel.setOpaque(false);

        gridPanel.add(createModernCard("👥 Patient Hub", "Register, Monitor & Track", new Color(66, 133, 244), () -> new PatientForm()));
        gridPanel.add(createModernCard("📆 Scheduler", "Plan Appointments Seamlessly", new Color(156, 39, 176), () -> new AppointmentForm()));
        gridPanel.add(createModernCard("📋 E-Records", "Secure Medical Documentation", new Color(243, 156, 18), () -> new MedicalRecordForm()));
        gridPanel.add(createModernCard("🩺 Doctor Hub", "Add & View Doctors", new Color(52, 152, 219), () -> new Doctorform()));
        gridPanel.add(createModernCard("💵 Billing Suite", "Handle Invoices & Charges", new Color(230, 126, 34), () -> new BillForm()));
        gridPanel.add(createModernCard("💳 Transactions", "Track & Process Payments", new Color(26, 188, 156), () -> new PaymentForm()));
        gridPanel.add(createModernCard("💊 Pharmacy", "Prescribe & Manage Medications", new Color(231, 76, 60), () -> new PrescriptionForm()));
        gridPanel.add(createModernCard("🧪 Lab Reports", "View & Manage Patient Reports", new Color(26, 188, 156), () -> new LabReport(123, true)));
        gridPanel.add(createModernCard("🗂️ View Feedback", "See What Users Are Saying", new Color(155, 89, 182), () -> new ShowFeedback()));

        JPanel centerWrap = new JPanel(new GridBagLayout());
        centerWrap.setOpaque(false);
        centerWrap.add(gridPanel);
        mainPanel.add(centerWrap, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createModernCard(String title, String subtitle, Color color, Runnable action) {
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(color);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                super.paintComponent(g);
            }
        };

        card.setOpaque(false);
        card.setPreferredSize(new Dimension(220, 120));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD, 17));

        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setForeground(new Color(255, 255, 255, 220));
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JPanel textPanel = new JPanel(new GridLayout(2, 1));
        textPanel.setOpaque(false);
        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        card.add(textPanel, BorderLayout.CENTER);
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(255, 255, 255, 90), 2),
                        BorderFactory.createEmptyBorder(18, 18, 18, 18)
                ));
                card.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                card.repaint();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                action.run();
            }
        });

        return card;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminForm::new);
    }
}
