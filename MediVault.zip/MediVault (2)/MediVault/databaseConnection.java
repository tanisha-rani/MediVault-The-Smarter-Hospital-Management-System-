import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class databaseConnection {

    // MySQL JDBC URL, username, and password
    private static final String URL = "jdbc:mysql://localhost:3306/MediVault";
    private static final String USER = "root";
    private static final String PASSWORD = "tanisha";

    // Method to establish the connection
    public static Connection getConnection() throws SQLException {
        // Load and register the JDBC driver (optional for newer versions)
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // MySQL driver class
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Establish and return the connection
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void main(String[] args) {
        try {
            Connection conn = databaseConnection.getConnection();
            System.out.println("Connection successful: " + conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
