import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.List;

public class AppointmentForm extends JFrame {
    private JTextField dateField;
    private JComboBox<String> hourCombo;
    private JComboBox<String> minuteCombo;
    private JComboBox<String> doctorComboBox;
    private JTextArea doctorDetailsArea;
    private JComboBox<String> concernComboBox;
    private JTextField patientIdField;
    private JTextField patientName;
    private JButton checkLastVisitButton;

    private final Map<String, List<Doctor>> concernToDoctors = new HashMap<>();

    private static final String DB_URL = "jdbc:mysql://localhost:3306/medivault";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "tanisha";

    public AppointmentForm() {
        setTitle("Schedule Appointment");
        setSize(500, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        populateConcernDoctorMap();

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(250, 252, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        patientIdField = new JTextField();
        patientName = new JTextField();

        concernComboBox = new JComboBox<>(new String[]{"Heart", "Skin", "Neurology", "Orthopedic", "General", "Children"});
        doctorComboBox = new JComboBox<>();
        doctorDetailsArea = new JTextArea(7, 20);
        doctorDetailsArea.setEditable(false);
        JScrollPane doctorDetailsScrollPane = new JScrollPane(doctorDetailsArea);

        concernComboBox.addActionListener(e -> {
            String concern = (String) concernComboBox.getSelectedItem();
            updateDoctorComboBox(concern.toLowerCase());
        });

        dateField = new JTextField();
        dateField.setEditable(false);
        dateField.setCursor(new Cursor(Cursor.HAND_CURSOR));
        dateField.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                openCalendarDialog();
            }
        });

        hourCombo = new JComboBox<>(createRange(0, 23));
        minuteCombo = new JComboBox<>(new String[]{"00", "15", "30", "45"});

        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        timePanel.setBackground(new Color(250, 252, 255));
        timePanel.add(hourCombo);
        timePanel.add(new JLabel(":"));
        timePanel.add(minuteCombo);

        JButton saveButton = new JButton("Schedule");
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        saveButton.setBackground(new Color(0, 123, 255));
        saveButton.setForeground(Color.WHITE);
        saveButton.setPreferredSize(new Dimension(150, 35));
        saveButton.addActionListener(e -> saveAppointment());

        checkLastVisitButton = new JButton("Check Last Visit");
        checkLastVisitButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        checkLastVisitButton.addActionListener(e -> checkLastVisit());

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Patient ID:"), gbc);
        gbc.gridx = 1;
        panel.add(patientIdField, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Patient Name:"), gbc);
        gbc.gridx = 1;
        panel.add(patientName, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Concern:"), gbc);
        gbc.gridx = 1;
        panel.add(concernComboBox, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Doctor Name:"), gbc);
        gbc.gridx = 1;
        panel.add(doctorComboBox, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        panel.add(dateField, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Time (HH:MM):"), gbc);
        gbc.gridx = 1;
        panel.add(timePanel, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(new JLabel("Doctor Details:"), gbc);
        gbc.gridx = 1;
        panel.add(doctorDetailsScrollPane, gbc); row++;

        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(saveButton, gbc); row++;

        gbc.gridy = row;
        panel.add(checkLastVisitButton, gbc);

        add(panel);
        setVisible(true);
    }

    private void populateConcernDoctorMap() {
        concernToDoctors.put("heart", List.of(new Doctor("Dr. Rajeev Pillai", "Cardiologist", "10 years", "MBBS, MD (Cardiology)", "Apollo Hospital, Delhi", "Mon-Fri: 10AM - 4PM", "rajeev.p@apollo.in", "+91-9812345678")));
        concernToDoctors.put("skin", List.of(new Doctor("Dr. Sneha Kapoor", "Dermatologist", "5 years", "MBBS, DDVL", "Dermacare Clinic, Pune", "Mon-Sat: 11AM - 2PM", "sneha.k@dermacare.com", "+91-9845678901")));
        concernToDoctors.put("neurology", List.of(new Doctor("Dr. Rohan Mehra", "Neurologist", "6 years", "MBBS, DM (Neurology)", "AIIMS, Delhi", "Mon-Fri: 10AM - 2PM", "rohan.m@aiims.edu", "+91-9889012345")));
        concernToDoctors.put("orthopedic", List.of(new Doctor("Dr. Vishal Rana", "Orthopedic Surgeon", "12 years", "MBBS, MS (Ortho)", "Max Hospital, Dehradun", "Mon-Fri: 9AM - 1PM", "vishal.r@maxhealth.in", "+91-9901234567")));
        concernToDoctors.put("general", List.of(new Doctor("Dr. Amit Roy", "General Physician", "10 years", "MBBS", "Care Clinic, Ranchi", "Mon-Sat: 10AM - 1PM", "amit.r@careclinic.in", "+91-9934567890")));
        concernToDoctors.put("children", List.of(new Doctor("Dr. Rajesh Kumar", "Pediatrician", "10 years", "MBBS, MD", "ChildCare, Kanpur", "Mon-Fri: 10AM - 1PM", "rajesh.k@childcare.in", "+91-9001234567")));
    }

    private void updateDoctorComboBox(String concern) {
        doctorComboBox.removeAllItems();
        for (ActionListener al : doctorComboBox.getActionListeners()) {
            doctorComboBox.removeActionListener(al);
        }

        List<Doctor> doctors = concernToDoctors.getOrDefault(concern, new ArrayList<>());
        for (Doctor doc : doctors) {
            doctorComboBox.addItem(doc.getName());
        }

        if (!doctors.isEmpty()) {
            doctorComboBox.addActionListener(e -> displayDoctorDetails((String) doctorComboBox.getSelectedItem()));
            doctorComboBox.setSelectedIndex(0);
            displayDoctorDetails(doctors.get(0).getName());
        } else {
            doctorComboBox.addItem("No matching doctors");
            doctorDetailsArea.setText("");
        }
    }

    private void displayDoctorDetails(String name) {
        for (List<Doctor> list : concernToDoctors.values()) {
            for (Doctor doc : list) {
                if (doc.getName().equals(name)) {
                    doctorDetailsArea.setText(
                        "Name: " + doc.getName() + "\n" +
                        "Specialization: " + doc.getSpecialization() + "\n" +
                        "Experience: " + doc.getExperience() + "\n" +
                        "Qualifications: " + doc.getQualifications() + "\n" +
                        "Hospital: " + doc.getHospital() + "\n" +
                        "Availability: " + doc.getAvailability() + "\n" +
                        "Email: " + doc.getContact() + "\n" +
                        "Phone: " + doc.getPhone()
                    );
                    return;
                }
            }
        }
    }

    private void openCalendarDialog() {
        JDialog dialog = new JDialog(this, "Select Date", true);
        dialog.setSize(350, 300);
        dialog.setLayout(new BorderLayout());
        dialog.setLocationRelativeTo(this);

        JPanel headerPanel = new JPanel(new FlowLayout());
        JComboBox<String> monthBox = new JComboBox<>(new String[]{
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        });
        JComboBox<Integer> yearBox = new JComboBox<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = currentYear - 50; i <= currentYear + 10; i++) {
            yearBox.addItem(i);
        }

        Calendar cal = Calendar.getInstance();
        monthBox.setSelectedIndex(cal.get(Calendar.MONTH));
        yearBox.setSelectedItem(cal.get(Calendar.YEAR));
        headerPanel.add(monthBox);
        headerPanel.add(yearBox);
        dialog.add(headerPanel, BorderLayout.NORTH);

        JPanel calendarPanel = new JPanel(new GridLayout(0, 7));
        dialog.add(calendarPanel, BorderLayout.CENTER);

        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

        ActionListener refreshCalendar = e -> {
            calendarPanel.removeAll();
            for (String d : days) calendarPanel.add(new JLabel(d, SwingConstants.CENTER));

            Calendar c = Calendar.getInstance();
            c.set(Calendar.MONTH, monthBox.getSelectedIndex());
            c.set(Calendar.YEAR, (Integer) yearBox.getSelectedItem());
            c.set(Calendar.DAY_OF_MONTH, 1);

            int firstDay = c.get(Calendar.DAY_OF_WEEK);
            int maxDay = c.getActualMaximum(Calendar.DAY_OF_MONTH);
            int day = 1;

            for (int i = 1; i < firstDay; i++) calendarPanel.add(new JLabel(""));

            for (int i = firstDay; i < firstDay + maxDay; i++) {
                JButton btn = new JButton(String.valueOf(day));
                int selectedDay = day;
                int selectedMonth = monthBox.getSelectedIndex() + 1;
                int selectedYear = (Integer) yearBox.getSelectedItem();

                btn.addActionListener(ev -> {
                    String formattedDate = String.format("%04d-%02d-%02d", selectedYear, selectedMonth, selectedDay);
                    dateField.setText(formattedDate);
                    dialog.dispose();
                });

                calendarPanel.add(btn);
                day++;
            }

            calendarPanel.revalidate();
            calendarPanel.repaint();
        };

        monthBox.addActionListener(refreshCalendar);
        yearBox.addActionListener(refreshCalendar);
        refreshCalendar.actionPerformed(null);

        dialog.setVisible(true);
    }

    private void saveAppointment() {
        String patientId = patientIdField.getText().trim();
        String name = patientName.getText().trim();
        String concern = (String) concernComboBox.getSelectedItem();
        String doctor = (String) doctorComboBox.getSelectedItem();
        String date = dateField.getText().trim();
        String time = hourCombo.getSelectedItem() + ":" + minuteCombo.getSelectedItem();

        if (patientId.isEmpty() || name.isEmpty() || date.isEmpty() || doctor == null) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "INSERT INTO appointment_table (patient_id, patient_name, medical_concern, doctor_name, appointment_date, timing) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, patientId);
            stmt.setString(2, name);
            stmt.setString(3, concern);
            stmt.setString(4, doctor);
            stmt.setDate(5, java.sql.Date.valueOf(date));
            stmt.setTime(6, java.sql.Time.valueOf(time + ":00"));

            int rows = stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Appointment Scheduled Successfully!" : "Failed to save appointment.");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void checkLastVisit() {
        String patientId = patientIdField.getText().trim();
        String doctor = (String) doctorComboBox.getSelectedItem();

        if (patientId.isEmpty() || doctor == null || doctor.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Patient ID and select Doctor.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT appointment_date, timing FROM appointment_table WHERE patient_id = ? AND doctor_name = ? ORDER BY appointment_date DESC, timing DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, patientId);
            stmt.setString(2, doctor);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String date = rs.getString("appointment_date");
                String time = rs.getString("timing");
                JOptionPane.showMessageDialog(this, "Last Visit:\nDate: " + date + "\nTime: " + time);
            } else {
                JOptionPane.showMessageDialog(this, "No previous appointment found.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private String[] createRange(int start, int end) {
        String[] range = new String[end - start + 1];
        for (int i = 0; i < range.length; i++) {
            range[i] = String.format("%02d", start + i);
        }
        return range;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AppointmentForm::new);
    }
}

class Doctor {
    private final String name, specialization, experience, qualifications, hospital, availability, contact, phone;

    public Doctor(String name, String specialization, String experience, String qualifications,
                  String hospital, String availability, String contact, String phone) {
        this.name = name;
        this.specialization = specialization;
        this.experience = experience;
        this.qualifications = qualifications;
        this.hospital = hospital;
        this.availability = availability;
        this.contact = contact;
        this.phone = phone;
    }

    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public String getExperience() { return experience; }
    public String getQualifications() { return qualifications; }
    public String getHospital() { return hospital; }
    public String getAvailability() { return availability; }
    public String getContact() { return contact; }
    public String getPhone() { return phone; }
}
